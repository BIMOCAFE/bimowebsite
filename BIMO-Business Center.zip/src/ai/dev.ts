import { config } from 'dotenv';
config();

import '@/ai/flows/product-recommendation.ts';
import '@/ai/flows/chatbot.ts';
