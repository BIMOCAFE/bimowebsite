'use server';

/**
 * @fileOverview An AI agent that generates personalized product recommendations based on user preferences and browsing history.
 *
 * - generateProductRecommendations - A function that generates product recommendations.
 * - ProductRecommendationInput - The input type for the generateProductRecommendations function.
 * - ProductRecommendationOutput - The return type for the generateProductRecommendations function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const ProductRecommendationInputSchema = z.object({
  userPreferences: z
    .string()
    .describe('A description of the user\s stated preferences.'),
  browsingHistory: z
    .string()
    .describe('A summary of the user\s browsing history on the website.'),
});
export type ProductRecommendationInput = z.infer<typeof ProductRecommendationInputSchema>;

const ProductRecommendationOutputSchema = z.object({
  recommendedProducts: z
    .array(z.string())
    .describe('A list of product names recommended for the user.'),
  reasoning: z
    .string()
    .describe('The AI\s reasoning for recommending these products.'),
});
export type ProductRecommendationOutput = z.infer<typeof ProductRecommendationOutputSchema>;

export async function generateProductRecommendations(
  input: ProductRecommendationInput
): Promise<ProductRecommendationOutput> {
  return productRecommendationFlow(input);
}

const productRecommendationPrompt = ai.definePrompt({
  name: 'productRecommendationPrompt',
  input: {schema: ProductRecommendationInputSchema},
  output: {schema: ProductRecommendationOutputSchema},
  prompt: `You are a personal shopping assistant. You will generate a list of products a user might be interested in based on their stated preferences and browsing history.

User Preferences: {{{userPreferences}}}
Browsing History: {{{browsingHistory}}}

Based on this information, recommend a list of products and explain your reasoning.`,
});

const productRecommendationFlow = ai.defineFlow(
  {
    name: 'productRecommendationFlow',
    inputSchema: ProductRecommendationInputSchema,
    outputSchema: ProductRecommendationOutputSchema,
  },
  async input => {
    const {output} = await productRecommendationPrompt(input);
    return output!;
  }
);
