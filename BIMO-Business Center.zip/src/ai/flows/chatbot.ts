'use server';

/**
 * @fileOverview A conversational AI agent for Bright Ideas Multi Outlet (BIMO).
 *
 * - chatWithBimo - A function that handles the conversational chat with the AI assistant.
 */

import { ai } from '@/ai/genkit';
import { products, services, outlets } from '@/lib/data';
import { z } from 'zod';

const BimoChatInputSchema = z.object({
  message: z.string().describe('The user\'s message to the chatbot.'),
  history: z.array(z.object({
    role: z.enum(['user', 'model']),
    content: z.array(z.object({ text: z.string() }))
  })).describe('The conversation history.'),
});

const BimoChatOutputSchema = z.object({
  response: z.string().describe('The AI\'s response to the user.'),
});


export async function chatWithBimo(
  input: z.infer<typeof BimoChatInputSchema>
): Promise<z.infer<typeof BimoChatOutputSchema>> {
  return bimoChatFlow(input);
}

const bimoChatFlow = ai.defineFlow(
  {
    name: 'bimoChatFlow',
    inputSchema: BimoChatInputSchema,
    outputSchema: BimoChatOutputSchema,
  },
  async ({ message, history }) => {
    const productAndServiceData = `
        Outlets:
        ${JSON.stringify(outlets, null, 2)}

        Products:
        ${JSON.stringify(products, null, 2)}

        Services:
        ${JSON.stringify(services, null, 2)}
        `;

    const result = await ai.generate({
      model: 'googleai/gemini-2.5-flash',
      system: `You are a friendly and helpful customer service assistant for Bimo, a company in Sierra Leone. Your goal is to answer user questions about Bimo's products and services and help them find what they need.

      Keep your responses concise, helpful, and friendly.

      You are empowered to negotiate prices and offer discounts. Here are the rules:
      - For any total purchase over NLe 100, you can offer a 10% discount on the entire order.
      - For "Photocopy Black and White", if a customer is printing 50 pages or more, the price is NLe 0.50 per page, not NLe 1.00. Mention this if they ask about bulk photocopying.

      Use the following data about the company's outlets, products, and services to answer questions. Do not make up information. If you don't know the answer, politely say that you can't help with that.

      The currency is Sierra Leonean Leones (NLe).

      Current Date: ${new Date().toLocaleDateString()}

      DATA:
      ${productAndServiceData}
      `,
      history,
      prompt: message,
    });

    const text = result.text;
    
    return { response: text };
  }
);
