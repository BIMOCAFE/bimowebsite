
"use client";

import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { outlets } from "@/lib/data";
import { useToast } from "@/hooks/use-toast";
import { Loader2, Send } from "lucide-react";
import { useState } from "react";
import { addDoc, collection, serverTimestamp, type Firestore } from "firebase/firestore";
import { useFirestore } from "@/firebase";
import { errorEmitter } from "@/firebase/error-emitter";
import { FirestorePermissionError } from "@/firebase/errors";

const formSchema = z.object({
  name: z.string().min(2, "Name must be at least 2 characters."),
  email: z.string().email("Please enter a valid email address."),
  department: z.string().min(1, "Please select a department."),
  message: z.string().min(10, "Message must be at least 10 characters."),
});

// This function will handle the actual Firestore document creation.
// It includes our improved error handling.
async function submitContactMessage(db: Firestore, values: z.infer<typeof formSchema>) {
    const contactMessagesCol = collection(db, "contactMessages");
    const payload = {
        ...values,
        createdAt: serverTimestamp(),
    };

    return addDoc(contactMessagesCol, payload)
        .catch(async (serverError) => {
            const permissionError = new FirestorePermissionError({
                path: contactMessagesCol.path,
                operation: 'create',
                requestResourceData: payload,
            });
            errorEmitter.emit('permission-error', permissionError);
            // Re-throw the error to be caught by the calling function's catch block
            throw serverError;
        });
}


export default function ContactForm() {
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const firestore = useFirestore();

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: "",
      email: "",
      department: "",
      message: "",
    },
  });

  function onSubmit(values: z.infer<typeof formSchema>) {
    if (!firestore) {
        toast({
            variant: "destructive",
            title: "Database Not Connected",
            description: "Please check your connection and try again.",
        });
        return;
    }
    
    setIsSubmitting(true);

    submitContactMessage(firestore, values)
        .then(() => {
            toast({
                title: "Message Sent!",
                description: "Thank you for contacting us. We'll be in touch shortly.",
            });
            setIsSubmitted(true);
            form.reset();
        })
        .catch((error) => {
            console.error("Error writing document: ", error);
            // The FirebaseErrorListener will show a more detailed toast in development.
            // This is a fallback for other errors.
            if (!(error instanceof FirestorePermissionError)) {
                 toast({
                    variant: "destructive",
                    title: "Uh oh! Something went wrong.",
                    description: "There was a problem sending your message. Please try again.",
                });
            }
        })
        .finally(() => {
            setIsSubmitting(false);
        });
  }

  if (isSubmitted) {
    return (
        <Card className="text-center p-8">
            <CardTitle className="text-2xl font-headline mb-4">Thank You!</CardTitle>
            <p className="text-muted-foreground">Your message has been sent successfully. We will get back to you soon.</p>
             <Button onClick={() => setIsSubmitted(false)} className="mt-4">Send Another Message</Button>
        </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Send us a Message</CardTitle>
      </CardHeader>
      <CardContent>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <FormField
              control={form.control}
              name="name"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Your Name</FormLabel>
                  <FormControl>
                    <Input placeholder="John Doe" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="email"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Your Email</FormLabel>
                  <FormControl>
                    <Input placeholder="john.doe@example.com" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="department"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Department</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Select a department to contact" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {outlets.map((outlet) => (
                        <SelectItem key={outlet.slug} value={outlet.slug}>
                          {outlet.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="message"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Your Message</FormLabel>
                  <FormControl>
                    <Textarea
                      placeholder="Tell us how we can help..."
                      className="min-h-[120px]"
                      {...field}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <Button type="submit" className="w-full bg-accent text-accent-foreground hover:bg-accent/90" disabled={isSubmitting}>
              {isSubmitting ? (
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              ) : (
                <Send className="mr-2 h-4 w-4"/>
              )}
              {isSubmitting ? 'Sending...' : 'Send Message'}
            </Button>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
}
