import { outlets } from "@/lib/data";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Globe, Mail, MapPin, Phone, User, Award, History } from "lucide-react";
import Image from "next/image";

export default function AboutPage() {
  return (
    <div className="container mx-auto py-12 px-4">
      <div className="text-center space-y-4 mb-12 max-w-3xl mx-auto">
        <h1 className="text-4xl md:text-5xl font-bold font-headline">
          About Bright Ideas Multi Outlet (BIMO)
        </h1>
        <div className="text-muted-foreground md:text-lg space-y-4">
            <p>
            Bright Ideas Multi Outlet (BIMO) started operations in 2015 with an Internet Cafe and Software Solutions. In 2024, we incorporated a Provision Shop and plan to include Computer and Electronics sales in 2025.
            </p>
            <p>
            So far, the business has been successful and consistent, operating a standard WhatsApp group for customers with over 300 participants.
            </p>
        </div>
      </div>

      <div className="space-y-12">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            <h2 className="text-3xl font-bold font-headline mb-6 flex items-center gap-3"><History /> Our History</h2>
            <div className="space-y-4 text-muted-foreground bg-secondary/30 p-6 rounded-lg">
                <p>The journey of Bright Ideas Multi Outlet (BIMO) began in 2015. Founded by Ibrahim Sorie Kamara, a passionate business entrepreneur, the company started as a humble internet cafe. With a vision to provide essential digital services to the community, BIMO quickly became a go-to hub for internet access and software solutions.</p>
                <p>Driven by a commitment to growth and meeting customer needs, BIMO has expanded significantly over the years. In 2024, we proudly launched our Provision Shop, and we have exciting plans to introduce an Electronics department in 2025. From a single cafe, BIMO has evolved into a multi-faceted outlet, demonstrating a history of success, consistency, and dedication to serving our loyal customers.</p>
            </div>
          </div>
          <div className="lg:col-span-1">
             <h2 className="text-3xl font-bold font-headline mb-6 flex items-center gap-3"><User /> Meet the CEO</h2>
             <Card>
                <CardContent className="p-6 text-center">
                    <div className="relative w-32 h-32 rounded-full mx-auto mb-4 overflow-hidden ring-4 ring-primary/20">
                         <Image 
                            src="https://picsum.photos/seed/ceo/200/200" 
                            alt="CEO Ibrahim Sorie Kamara"
                            fill
                            className="object-cover"
                            data-ai-hint="professional portrait"
                        />
                    </div>
                    <h3 className="text-xl font-bold">Ibrahim Sorie Kamara</h3>
                    <p className="text-sm text-primary font-medium">Founder & CEO</p>
                    <p className="text-muted-foreground mt-2 text-sm">Ibrahim is a visionary business entrepreneur and a proud holder of a BSc. in Computer Science from the University of the People. His passion for technology and community service is the driving force behind BIMO's success.</p>
                </CardContent>
             </Card>
          </div>
        </div>

        <div>
          <h2 className="text-3xl font-bold font-headline text-center mb-8">Our Locations</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {outlets.map((outlet) => (
              (outlet.address || outlet.emails || outlet.phones || outlet.website) && (
                <Card key={outlet.slug}>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-3">
                      <outlet.icon className="w-7 h-7 text-primary" />
                      {outlet.name}
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {outlet.address && (
                       <div className="flex items-start gap-3">
                        <MapPin className="w-5 h-5 mt-1 text-muted-foreground" />
                        <p>{outlet.address}</p>
                       </div>
                    )}
                    {outlet.emails && outlet.emails.length > 0 && (
                      <div className="flex items-start gap-3">
                        <Mail className="w-5 h-5 mt-1 text-muted-foreground" />
                        <div>
                          {outlet.emails.map(email => <p key={email}>{email}</p>)}
                        </div>
                      </div>
                    )}
                    {outlet.phones && outlet.phones.length > 0 && (
                       <div className="flex items-start gap-3">
                        <Phone className="w-5 h-5 mt-1 text-muted-foreground" />
                        <div>
                           {outlet.phones.map(phone => <p key={phone}>{phone}</p>)}
                        </div>
                       </div>
                    )}
                     {outlet.website && (
                      <div className="flex items-start gap-3">
                        <Globe className="w-5 h-5 mt-1 text-muted-foreground" />
                        <a href={outlet.website} target="_blank" rel="noopener noreferrer" className="hover:underline">{outlet.website}</a>
                      </div>
                    )}
                  </CardContent>
                </Card>
              )
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
