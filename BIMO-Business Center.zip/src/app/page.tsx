import { ArrowRight } from 'lucide-react';
import Link from 'next/link';
import Image from 'next/image';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { outlets } from '@/lib/data';
import { PlaceHolderImages } from '@/lib/placeholder-images';

export default function Home() {
  const heroImage = PlaceHolderImages.find(p => p.id === 'hero');

  return (
    <div className="flex flex-col">
      <section className="relative w-full h-[60vh] md:h-[70vh]">
        {heroImage && (
           <Image
            src={heroImage.imageUrl}
            alt={heroImage.description}
            fill
            className="object-cover"
            priority
            data-ai-hint={heroImage.imageHint}
          />
        )}
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
        <div className="relative container mx-auto flex flex-col items-center justify-center h-full text-center text-white space-y-6 px-4">
          <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold font-headline tracking-tighter">
            Welcome to Bright Ideas Multi Outlet (BIMO)
          </h1>
          <p className="max-w-3xl text-lg md:text-xl text-neutral-200">
            Your centralized destination for products and services. From internet cafes to custom software, we've got you covered.
          </p>
          <div>
            <Button asChild size="lg" className="bg-accent text-accent-foreground hover:bg-accent/90">
              <Link href="/outlets">
                Explore Our Outlets <ArrowRight className="ml-2 h-5 w-5" />
              </Link>
            </Button>
          </div>
        </div>
      </section>

      <section id="outlets" className="py-12 md:py-20 lg:py-24">
        <div className="container mx-auto px-4">
          <div className="text-center space-y-4 mb-12">
            <h2 className="text-3xl md:text-4xl font-bold font-headline">Our Business Outlets</h2>
            <p className="max-w-2xl mx-auto text-muted-foreground md:text-lg">
              Discover the diverse range of businesses under the BIMO umbrella.
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {outlets.map((outlet) => {
              const outletImage = PlaceHolderImages.find(p => p.id === outlet.slug);
              return (
              <Link href={`/outlets/${outlet.slug}`} key={outlet.slug}>
                <Card className="h-full overflow-hidden transition-all duration-300 hover:shadow-xl hover:-translate-y-2 flex flex-col">
                  <CardHeader className="p-0">
                    {outletImage && (
                      <div className="aspect-video relative">
                        <Image
                          src={outletImage.imageUrl}
                          alt={outlet.name}
                          fill
                          className="object-cover"
                          data-ai-hint={outletImage.imageHint}
                        />
                      </div>
                    )}
                  </CardHeader>
                  <CardContent className="p-6 flex-grow flex flex-col">
                    <div className="flex items-center gap-3 mb-4">
                       <outlet.icon className="w-8 h-8 text-primary" />
                       <h3 className="text-xl font-bold font-headline">{outlet.name}</h3>
                    </div>
                    <p className="text-muted-foreground flex-grow">{outlet.description}</p>
                  </CardContent>
                </Card>
              </Link>
            )})}
          </div>
        </div>
      </section>

      <section className="bg-secondary py-12 md:py-20 lg:py-24">
        <div className="container mx-auto px-4 text-center">
            <h2 className="text-3xl md:text-4xl font-bold font-headline mb-4">Need a Recommendation?</h2>
            <p className="max-w-2xl mx-auto text-muted-foreground md:text-lg mb-8">
              Let our AI-powered assistant help you find the perfect product or service based on your needs.
            </p>
            <Button asChild size="lg" className="bg-accent text-accent-foreground hover:bg-accent/90">
                <Link href="/recommendations">
                    Try AI Recommender
                </Link>
            </Button>
        </div>
      </section>
    </div>
  );
}
