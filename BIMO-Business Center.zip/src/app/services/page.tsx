'use client';

import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { services } from '@/lib/data';
import { PlaceHolderImages } from '@/lib/placeholder-images';
import Image from 'next/image';
import { Button } from '@/components/ui/button';
import { ShoppingCart } from 'lucide-react';
import { useCart } from '@/context/cart-context';

export default function ServicesPage() {
  const currency = 'NLe';
  const { addToCart } = useCart();

  return (
    <div className="container mx-auto py-12 px-4">
      <div className="text-center space-y-4 mb-12">
        <h1 className="text-4xl md:text-5xl font-bold font-headline">Our Services</h1>
        <p className="max-w-2xl mx-auto text-muted-foreground md:text-lg">
          We offer professional application development and other digital services to bring your ideas to life.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {services.map((service) => {
          const serviceImage = PlaceHolderImages.find(p => p.id === service.id);
          return (
            <Card key={service.id} className="h-full overflow-hidden transition-all duration-300 hover:shadow-xl hover:-translate-y-2 flex flex-col">
              {serviceImage && (
                <CardHeader className="p-0">
                  <div className="aspect-video relative">
                    <Image
                      src={serviceImage.imageUrl}
                      alt={service.name}
                      fill
                      className="object-cover"
                      data-ai-hint={serviceImage.imageHint}
                    />
                  </div>
                </CardHeader>
              )}
              <CardContent className="p-6 flex-grow flex flex-col text-center">
                <div className="mx-auto bg-primary/10 rounded-full h-20 w-20 flex items-center justify-center mb-4 -mt-16 bg-background border-4 border-background hover:scale-110 transition-transform">
                  <service.icon className="w-10 h-10 text-primary" />
                </div>
                <CardTitle className="font-headline text-xl mb-2">{service.name}</CardTitle>
                <p className="text-muted-foreground flex-grow mb-4">{service.description}</p>
                <p className="text-lg font-bold text-primary">{currency}{service.price.toFixed(2)}</p>
              </CardContent>
              <CardFooter className="flex justify-center items-center p-4 pt-0">
                <Button onClick={() => addToCart(service)} className="w-full">
                  <ShoppingCart className="mr-2 h-4 w-4" />
                  Add to Cart
                </Button>
              </CardFooter>
            </Card>
          )
        })}
      </div>
    </div>
  );
}
