
import { products, services } from '@/lib/data';
import { PlaceHolderImages } from '@/lib/placeholder-images';
import Image from 'next/image';
import Link from 'next/link';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { ArrowRight } from 'lucide-react';
import { Badge } from '@/components/ui/badge';

// A curated list of items to feature in the portfolio
const portfolioItems = [
  ...services.slice(0, 3), // First 3 services
  ...products.filter(p => ['prod-007', 'prod-008', 'prod-002'].includes(p.id)) // Specific products
];


export default function PortfolioPage() {
  return (
    <div className="container mx-auto py-12 px-4">
      <div className="text-center space-y-4 mb-12">
        <h1 className="text-4xl md:text-5xl font-bold font-headline">Our Work & Products</h1>
        <p className="max-w-2xl mx-auto text-muted-foreground md:text-lg">
          Here is a sample of the products we offer and the services we provide.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {portfolioItems.map((item) => {
          const isService = 'icon' in item;
          const image = PlaceHolderImages.find(p => p.id === item.id);
          const link = isService ? '/outlets/application-development' : `/outlets/${(item as any).outletSlug}`;
          
          return (
            <Link href={link} key={item.id} className="block group">
                <Card className="h-full overflow-hidden transition-all duration-300 hover:shadow-xl hover:-translate-y-2 flex flex-col">
                {image && (
                    <CardHeader className="p-0">
                    <div className="aspect-video relative">
                        <Image
                        src={image.imageUrl}
                        alt={item.name}
                        fill
                        className="object-cover"
                        data-ai-hint={image.imageHint}
                        />
                    </div>
                    </CardHeader>
                )}
                <CardContent className="p-6 flex-grow flex flex-col">
                    <CardTitle className="font-headline text-xl mb-2">{item.name}</CardTitle>
                    <p className="text-muted-foreground flex-grow mb-4">{item.description}</p>
                </CardContent>
                <CardFooter className="p-6 pt-0 flex justify-between items-center">
                    <Badge variant={isService ? "secondary" : "default"}>
                        {isService ? 'Service' : 'Product'}
                    </Badge>
                    <div className="flex items-center font-semibold text-primary">
                        <span>View More</span>
                        <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
                    </div>
                </CardFooter>
                </Card>
            </Link>
          )
        })}
      </div>
    </div>
  );
}
