import { onlineServices } from '@/lib/online-services';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ArrowUpRight, AlertTriangle } from 'lucide-react';
import Link from 'next/link';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';

export default function OnlineServicesPage() {
  const groupedServices = onlineServices.reduce((acc, service) => {
    if (!acc[service.category]) {
      acc[service.category] = [];
    }
    acc[service.category].push(service);
    return acc;
  }, {} as Record<string, typeof onlineServices>);

  return (
    <div className="container mx-auto py-12 px-4">
      <div className="text-center space-y-4 mb-12">
        <h1 className="text-4xl md:text-5xl font-bold font-headline">Online Services</h1>
        <p className="max-w-2xl mx-auto text-muted-foreground md:text-lg">
          Quick access to essential third-party online services. We provide these links for your convenience.
        </p>
      </div>

      <Alert className="mb-12 max-w-4xl mx-auto">
        <AlertTriangle className="h-4 w-4" />
        <AlertTitle>Important Disclaimer</AlertTitle>
        <AlertDescription>
          Please note: These links are provided for your convenience. The linked websites are subject to the Cyber Crime Act of 2021 and the laws of Sierra Leone. Users are responsible for their own conduct when visiting these external sites. Bright Ideas Multi Outlet (BIMO) is not responsible for the content or functionality of these third-party websites.
        </AlertDescription>
      </Alert>

      <div className="space-y-12">
        {Object.entries(groupedServices).map(([category, services]) => (
          <div key={category}>
            <h2 className="text-2xl font-bold font-headline mb-6">{category}</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {services.map((service) => (
                <Link href={service.url} target="_blank" rel="noopener noreferrer" key={service.id} className="block group">
                  <Card className="h-full transition-all duration-300 hover:shadow-xl hover:-translate-y-1">
                    <CardHeader className="flex flex-row items-center justify-between pb-2">
                      <CardTitle className="text-lg font-semibold">{service.name}</CardTitle>
                      <service.icon className="w-6 h-6 text-primary" />
                    </CardHeader>
                    <CardContent>
                      <p className="text-muted-foreground text-sm flex-grow mb-4">{service.description}</p>
                      <div className="flex items-center font-semibold text-sm text-primary">
                        <span>Visit Site</span>
                        <ArrowUpRight className="ml-1 h-4 w-4 transition-transform group-hover:translate-x-1 group-hover:-translate-y-1" />
                      </div>
                    </CardContent>
                  </Card>
                </Link>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
