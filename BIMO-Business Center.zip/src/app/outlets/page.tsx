import Link from 'next/link';
import Image from 'next/image';
import { outlets } from '@/lib/data';
import { Card } from '@/components/ui/card';
import { ArrowRight } from 'lucide-react';
import { PlaceHolderImages } from '@/lib/placeholder-images';

export default function OutletsPage() {
  return (
    <div className="container mx-auto py-12 px-4">
      <div className="text-center space-y-4 mb-12">
        <h1 className="text-4xl md:text-5xl font-bold font-headline">Our Outlets</h1>
        <p className="max-w-2xl mx-auto text-muted-foreground md:text-lg">
          Explore our diverse range of businesses, each offering unique products and services.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {outlets.map((outlet) => {
          const outletImage = PlaceHolderImages.find(p => p.id === outlet.slug);
          return (
          <Link href={`/outlets/${outlet.slug}`} key={outlet.slug}>
            <Card className="group overflow-hidden transition-shadow duration-300 hover:shadow-2xl h-full flex flex-col md:flex-row">
              {outletImage && (
                <div className="relative w-full md:w-1/3 aspect-video md:aspect-auto">
                  <Image
                    src={outletImage.imageUrl}
                    alt={outlet.name}
                    fill
                    className="object-cover"
                    data-ai-hint={outletImage.imageHint}
                  />
                </div>
              )}
              <div className="flex flex-col justify-between p-6 w-full md:w-2/3">
                <div>
                  <div className="flex items-center gap-3 mb-2">
                    <outlet.icon className="w-7 h-7 text-primary" />
                    <h2 className="text-2xl font-bold font-headline">{outlet.name}</h2>
                  </div>
                  <p className="text-muted-foreground mb-4">{outlet.description}</p>
                </div>
                <div className="flex items-center font-semibold text-primary">
                  <span>View {outlet.category}</span>
                  <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
                </div>
              </div>
            </Card>
          </Link>
        )})}
      </div>
    </div>
  );
}
