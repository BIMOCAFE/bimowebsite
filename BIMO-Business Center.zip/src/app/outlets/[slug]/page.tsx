'use client';

import { getOutletBySlug, getProductsByOutlet, getServicesByOutlet } from '@/lib/data';
import { notFound, useParams } from 'next/navigation';
import Image from 'next/image';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { PlaceHolderImages } from '@/lib/placeholder-images';
import Link from 'next/link';
import { Globe, Mail, MapPin, Phone, ShoppingCart } from 'lucide-react';
import { useCart } from '@/context/cart-context';
import { Button } from '@/components/ui/button';

export default function OutletDetailPage() {
  const params = useParams();
  const slug = Array.isArray(params.slug) ? params.slug[0] : params.slug;
  const { addToCart } = useCart();

  if (!slug) {
    // Or show a loading state
    return notFound();
  }

  const outlet = getOutletBySlug(slug);

  if (!outlet) {
    notFound();
  }

  const products = getProductsByOutlet(slug);
  const outletServices = getServicesByOutlet(slug);
  const outletImage = PlaceHolderImages.find(p => p.id === `${outlet.slug}-hero`);
  const currency = 'NLe';

  const isServiceOutlet = outlet.slug === 'application-development';

  return (
    <div>
      <section className="relative w-full h-64 bg-secondary">
        {outletImage && (
          <Image
            src={outletImage.imageUrl}
            alt={outlet.name}
            fill
            className="object-cover"
            data-ai-hint={outletImage.imageHint}
          />
        )}
        <div className="absolute inset-0 bg-black/50" />
        <div className="relative container mx-auto flex flex-col justify-center h-full text-white px-4">
          <div className="flex items-center gap-4">
            <outlet.icon className="w-16 h-16" />
            <div>
              <h1 className="text-4xl md:text-5xl font-bold font-headline">{outlet.name}</h1>
              <p className="text-lg text-neutral-200">{outlet.description}</p>
            </div>
          </div>
        </div>
      </section>

      <div className="container mx-auto py-12 px-4">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
          <div className="lg:col-span-2">
             {isServiceOutlet ? (
                <>
                  <h2 className="text-3xl font-bold font-headline mb-8">
                    Our Services
                  </h2>
                  <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-8">
                    {outletServices.map((service) => {
                      const serviceImage = PlaceHolderImages.find(p => p.id === service.id);
                      return (
                      <Card key={service.id} className="overflow-hidden flex flex-col">
                        <CardHeader className="p-0">
                          {serviceImage && (
                            <div className="aspect-square relative">
                              <Image
                                src={serviceImage.imageUrl}
                                alt={service.name}
                                fill
                                className="object-cover"
                                data-ai-hint={serviceImage.imageHint}
                              />
                            </div>
                          )}
                        </CardHeader>
                        <CardContent className="p-4 flex-grow">
                          <CardTitle className="text-lg font-semibold mb-2">{service.name}</CardTitle>
                          <p className="text-sm text-muted-foreground mb-4">{service.description}</p>
                           <p className="text-lg font-bold text-primary">{currency}{service.price.toFixed(2)}</p>
                        </CardContent>
                        <CardFooter className="p-4 pt-0">
                           <Button onClick={() => addToCart(service)} className="w-full">
                            <ShoppingCart className="mr-2 h-4 w-4" />
                            Add to Cart
                          </Button>
                        </CardFooter>
                      </Card>
                    )})}
                  </div>
                </>
              ) : (
                <>
                  <h2 className="text-3xl font-bold font-headline mb-8">
                    Available Products
                  </h2>
                  <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-8">
                    {products.map((product) => {
                      const productImage = PlaceHolderImages.find(p => p.id === product.id);
                      return (
                      <Card key={product.id} className="overflow-hidden flex flex-col">
                        <CardHeader className="p-0">
                          {productImage && (
                            <div className="aspect-square relative">
                              <Image
                                src={productImage.imageUrl}
                                alt={product.name}
                                fill
                                className="object-cover"
                                data-ai-hint={productImage.imageHint}
                              />
                            </div>
                          )}
                        </CardHeader>
                        <CardContent className="p-4 flex-grow">
                          <CardTitle className="text-lg font-semibold mb-2">{product.name}</CardTitle>
                          <p className="text-sm text-muted-foreground mb-4">{product.description}</p>
                           <p className="text-lg font-bold text-primary">{currency}{product.price.toFixed(2)}</p>
                            <Badge variant={product.isAvailable ? 'default' : 'destructive'} className='mt-2'>
                                {product.isAvailable ? 'In Stock' : 'Out of Stock'}
                            </Badge>
                        </CardContent>
                        <CardFooter className="p-4 pt-0">
                           <Button onClick={() => addToCart(product)} className="w-full" disabled={!product.isAvailable}>
                            <ShoppingCart className="mr-2 h-4 w-4" />
                            {product.isAvailable ? 'Add to Cart' : 'Out of Stock'}
                          </Button>
                        </CardFooter>
                      </Card>
                    )})}
                  </div>
                </>
              )}
          </div>
          <aside className="lg:col-span-1 space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Outlet Information</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {outlet.address && (
                  <div className="flex items-start gap-3">
                    <MapPin className="w-5 h-5 mt-1 text-muted-foreground flex-shrink-0" />
                    <p className="text-sm">{outlet.address}</p>
                  </div>
                )}
                {outlet.emails && outlet.emails.length > 0 && (
                  <div className="flex items-start gap-3">
                    <Mail className="w-5 h-5 mt-1 text-muted-foreground flex-shrink-0" />
                    <div className="text-sm">
                      {outlet.emails.map(email => <a href={`mailto:${email}`} key={email} className="block hover:underline">{email}</a>)}
                    </div>
                  </div>
                )}
                {outlet.phones && outlet.phones.length > 0 && (
                  <div className="flex items-start gap-3">
                    <Phone className="w-5 h-5 mt-1 text-muted-foreground flex-shrink-0" />
                    <div className="text-sm">
                        {outlet.phones.map(phone => <a href={`tel:${phone}`} key={phone} className="block hover:underline">{phone}</a>)}
                    </div>
                  </div>
                )}
                {outlet.website && (
                  <div className="flex items-start gap-3">
                    <Globe className="w-5 h-5 mt-1 text-muted-foreground flex-shrink-0" />
                    <a href={outlet.website} target="_blank" rel="noopener noreferrer" className="text-sm block hover:underline break-all">{outlet.website}</a>
                  </div>
                )}
              </CardContent>
            </Card>
          </aside>
        </div>
      </div>
    </div>
  );
}
