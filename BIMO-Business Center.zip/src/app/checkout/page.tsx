import CheckoutForm from "./checkout-form";

export default function CheckoutPage() {
  return (
    <div className="container mx-auto py-12 px-4">
      <div className="text-center space-y-4 mb-12 max-w-3xl mx-auto">
        <h1 className="text-4xl md:text-5xl font-bold font-headline">Checkout</h1>
        <p className="text-muted-foreground md:text-lg">
          Please review your order and provide your details to complete the purchase.
        </p>
      </div>
      <div className="max-w-4xl mx-auto">
        <CheckoutForm />
      </div>
    </div>
  );
}
