"use client";

import { useCart } from "@/context/cart-context";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { CreditCard, Landmark, Smartphone, User } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import Image from "next/image";
import { PlaceHolderImages } from "@/lib/placeholder-images";
import { useState } from "react";
import { Separator } from "@/components/ui/separator";

const formSchema = z.object({
  name: z.string().min(2, "Name must be at least 2 characters."),
  email: z.string().email("Please enter a valid email address."),
  phone: z.string().min(1, "Please enter a phone number."),
  paymentMethod: z.enum(["card", "mobile_money"], {
    required_error: "You need to select a payment method.",
  }),
});

export default function CheckoutForm() {
  const { cartItems, cartTotal, clearCart } = useCart();
  const { toast } = useToast();
  const [isSubmitted, setIsSubmitted] = useState(false);
  const currency = 'NLe';

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: "",
      email: "",
      phone: "",
    },
  });

  function onSubmit(values: z.infer<typeof formSchema>) {
    console.log("Form submitted:", values);
    toast({
      title: "Order Placed!",
      description: "Thank you for your order. We'll be in touch shortly.",
    });
    setIsSubmitted(true);
    clearCart();
    // In a real app, you would process the payment here
  }

  if (isSubmitted) {
    return (
        <Card className="text-center p-8">
            <CardTitle className="text-2xl font-headline mb-4">Thank You For Your Order!</CardTitle>
            <p className="text-muted-foreground">A confirmation has been sent to your email. We will contact you shortly with delivery details.</p>
        </Card>
    );
  }

  if (cartItems.length === 0 && !isSubmitted) {
      return (
          <Card className="text-center p-8">
              <CardTitle className="text-2xl font-headline mb-4">Your Cart is Empty</CardTitle>
              <p className="text-muted-foreground">There is nothing to check out. Please add items to your cart first.</p>
          </Card>
      )
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <Card>
                <CardHeader>
                    <CardTitle>Contact Information</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                     <FormField
                        control={form.control}
                        name="name"
                        render={({ field }) => (
                            <FormItem>
                            <FormLabel>Full Name</FormLabel>
                            <FormControl>
                                <Input placeholder="John Doe" {...field} />
                            </FormControl>
                            <FormMessage />
                            </FormItem>
                        )}
                        />
                    <FormField
                        control={form.control}
                        name="email"
                        render={({ field }) => (
                            <FormItem>
                            <FormLabel>Email Address</FormLabel>
                            <FormControl>
                                <Input placeholder="john.doe@example.com" {...field} />
                            </FormControl>
                            <FormMessage />
                            </FormItem>
                        )}
                        />
                    <FormField
                        control={form.control}
                        name="phone"
                        render={({ field }) => (
                            <FormItem>
                            <FormLabel>Phone Number</FormLabel>
                            <FormControl>
                                <Input placeholder="+232 12 345678" {...field} />
                            </FormControl>
                            <FormMessage />
                            </FormItem>
                        )}
                        />
                </CardContent>
            </Card>

            <Card>
                <CardHeader>
                    <CardTitle>Payment Method</CardTitle>
                    <CardDescription>This is a placeholder. No real payment will be processed.</CardDescription>
                </CardHeader>
                <CardContent>
                    <FormField
                        control={form.control}
                        name="paymentMethod"
                        render={({ field }) => (
                            <FormItem className="space-y-3">
                            <FormControl>
                                <RadioGroup
                                onValueChange={field.onChange}
                                defaultValue={field.value}
                                className="flex flex-col space-y-1"
                                >
                                <FormItem className="flex items-center space-x-3 space-y-0 rounded-md border p-4">
                                    <FormControl>
                                    <RadioGroupItem value="card" />
                                    </FormControl>
                                    <FormLabel className="font-normal flex items-center gap-2">
                                    <CreditCard/> Credit/Debit Card
                                    </FormLabel>
                                </FormItem>
                                <FormItem className="flex items-center space-x-3 space-y-0 rounded-md border p-4">
                                    <FormControl>
                                    <RadioGroupItem value="mobile_money" />
                                    </FormControl>
                                    <FormLabel className="font-normal flex items-center gap-2">
                                    <Smartphone/> Mobile Money
                                    </FormLabel>
                                </FormItem>
                                </RadioGroup>
                            </FormControl>
                            <FormMessage />
                            </FormItem>
                        )}
                        />
                </CardContent>
            </Card>
            
            <Button type="submit" className="w-full text-lg py-6">
              Place Order
            </Button>
          </form>
        </Form>
        <div className="space-y-4">
            <Card>
                <CardHeader>
                    <CardTitle>Order Summary</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                    <div className="space-y-2">
                        {cartItems.map(item => (
                            <div key={item.id} className="flex items-center justify-between">
                                <div className="flex items-center gap-2">
                                    <div className="relative w-12 h-12 rounded-md overflow-hidden">
                                        <Image src={PlaceHolderImages.find(p => p.id === item.id)?.imageUrl || ''} alt={item.name} fill className="object-cover" />
                                    </div>
                                    <div>
                                        <p className="font-medium">{item.name}</p>
                                        <p className="text-sm text-muted-foreground">Qty: {item.quantity}</p>
                                    </div>
                                </div>
                                <p>{currency}{(item.price * item.quantity).toFixed(2)}</p>
                            </div>
                        ))}
                    </div>
                    <Separator/>
                     <div className="flex justify-between">
                        <span>Subtotal</span>
                        <span>{currency}{cartTotal.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between text-sm text-muted-foreground">
                        <span>Taxes</span>
                        <span>{currency}0.00</span>
                    </div>
                    <Separator/>
                    <div className="flex justify-between font-bold text-lg">
                        <span>Total</span>
                        <span>{currency}{cartTotal.toFixed(2)}</span>
                    </div>
                </CardContent>
            </Card>
        </div>
    </div>
  );
}
