import RecommendationForm from "./recommendation-form";

export default function RecommendationsPage() {
  return (
    <div className="container mx-auto py-12 px-4">
      <div className="text-center space-y-4 mb-12 max-w-3xl mx-auto">
        <h1 className="text-4xl md:text-5xl font-bold font-headline">AI Product Recommender</h1>
        <p className="text-muted-foreground md:text-lg">
          Not sure what you're looking for? Describe your preferences and what you've been browsing, and our AI assistant will suggest products tailored just for you.
        </p>
      </div>
      <div className="max-w-3xl mx-auto">
        <RecommendationForm />
      </div>
    </div>
  );
}
