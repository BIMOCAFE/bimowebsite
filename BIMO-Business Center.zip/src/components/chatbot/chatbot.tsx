'use client';

import { useState, useRef, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Bot, Loader2, Send, X, User } from 'lucide-react';
import { chatWithBimo } from '@/ai/flows/chatbot';
import { ScrollArea } from '../ui/scroll-area';
import { Avatar, AvatarFallback } from '../ui/avatar';

type Message = {
    role: 'user' | 'model';
    content: { text: string }[];
};


export default function Chatbot() {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const viewportRef = useRef<HTMLDivElement>(null);


  useEffect(() => {
    if (viewportRef.current) {
        viewportRef.current.scrollTo({
            top: viewportRef.current.scrollHeight,
            behavior: 'smooth'
        });
    }
  }, [messages, isLoading]);

  const handleSend = async () => {
    if (!input.trim()) return;

    const userMessage = { role: 'user' as const, content: [{ text: input }] };
    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsLoading(true);

    try {
        const history = messages.map(m => ({
            role: m.role,
            content: m.content.map(c => ({ text: c.text }))
        }));
        
      const result = await chatWithBimo({ message: input, history });

      const modelMessage = { role: 'model' as const, content: [{ text: result.response }] };
      setMessages(prev => [...prev, modelMessage]);
    } catch (error) {
      console.error('Chatbot error:', error);
      const errorMessage = { role: 'model' as const, content: [{ text: "Sorry, I'm having trouble connecting. Please try again later." }] };
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <>
      <div className="fixed bottom-6 right-6 z-50">
        <Button
          size="icon"
          className="rounded-full h-16 w-16 bg-primary text-primary-foreground hover:bg-primary/90 shadow-lg"
          onClick={() => setIsOpen(!isOpen)}
        >
          {isOpen ? <X className="h-8 w-8" /> : <Bot className="h-8 w-8" />}
        </Button>
      </div>

      {isOpen && (
        <div className="fixed bottom-24 right-6 z-50">
            <Card className="w-80 h-[30rem] flex flex-col shadow-2xl animate-in fade-in-50 slide-in-from-bottom-5">
                <CardHeader className='border-b'>
                    <CardTitle className="flex items-center gap-2">
                        <Bot className="text-primary"/>
                        <span>Bimo Assistant</span>
                    </CardTitle>
                    <CardDescription>Ask me about products and services!</CardDescription>
                </CardHeader>
                <CardContent className="flex-grow p-0">
                    <ScrollArea className="h-full" viewportRef={viewportRef}>
                        <div className="p-4 space-y-4">
                            {messages.map((msg, index) => (
                                <div key={index} className={`flex items-start gap-2 ${msg.role === 'user' ? 'justify-end' : ''}`}>
                                     {msg.role === 'model' && (
                                        <Avatar className="h-8 w-8 bg-primary text-primary-foreground">
                                            <AvatarFallback><Bot className="h-5 w-5"/></AvatarFallback>
                                        </Avatar>
                                     )}
                                     <div className={`rounded-lg px-3 py-2 max-w-[80%] ${msg.role === 'user' ? 'bg-primary text-primary-foreground' : 'bg-secondary'}`}>
                                        <p className="text-sm whitespace-pre-wrap">{msg.content[0].text}</p>
                                     </div>
                                     {msg.role === 'user' && (
                                        <Avatar className="h-8 w-8 bg-muted text-muted-foreground">
                                            <AvatarFallback><User className="h-5 w-5"/></AvatarFallback>
                                        </Avatar>
                                     )}
                                </div>
                            ))}
                            {isLoading && (
                                <div className="flex items-start gap-2">
                                     <Avatar className="h-8 w-8 bg-primary text-primary-foreground">
                                        <AvatarFallback><Bot className="h-5 w-5"/></AvatarFallback>
                                    </Avatar>
                                    <div className="rounded-lg px-3 py-2 bg-secondary">
                                        <Loader2 className="h-5 w-5 animate-spin text-primary" />
                                    </div>
                                </div>
                            )}
                        </div>
                    </ScrollArea>
                </CardContent>
                <CardFooter className="p-2 border-t">
                    <div className="flex w-full items-center space-x-2">
                    <Input
                        value={input}
                        onChange={(e) => setInput(e.target.value)}
                        onKeyPress={(e) => e.key === 'Enter' && handleSend()}
                        placeholder="Type a message..."
                        disabled={isLoading}
                        className="border-destructive focus-visible:ring-destructive"
                    />
                    <Button type="submit" size="icon" onClick={handleSend} disabled={isLoading}>
                        <Send className="h-4 w-4" />
                        <span className="sr-only">Send</span>
                    </Button>
                    </div>
                </CardFooter>
            </Card>
        </div>
      )}
    </>
  );
}
