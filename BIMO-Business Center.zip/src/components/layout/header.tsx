
import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetDescription, SheetTrigger } from '@/components/ui/sheet';
import { Menu, Star, ShoppingCart } from 'lucide-react';
import CartButton from './cart-button';

const navLinks = [
  { href: '/', label: 'Home' },
  { href: '/outlets', label: 'Outlets' },
  { href: '/services', label: 'Services' },
  { href: '/online-services', label: 'Online Services' },
  { href: '/portfolio', label: 'Portfolio' },
  { href: '/about', label: 'About Us' },
  { href: '/recommendations', label: 'AI Recommends' },
  { href: '/contact', label: 'Contact Us' },
  { href: '/checkout', label: 'Checkout' },
];

export function Header() {
  return (
    <header className="sticky top-0 z-50 w-full border-b-2 border-primary bg-primary text-primary-foreground backdrop-blur supports-[backdrop-filter]:bg-primary/60">
      <div className="container flex h-14 items-center">
        <div className="mr-4 hidden w-full md:flex">
          <Link href="/" className="mr-6 flex items-center space-x-2">
            <Star className="h-6 w-6" />
            <span className="hidden font-bold lg:inline-block font-headline">
              Bright Ideas Multi Outlet
            </span>
             <span className="font-bold md:inline-block lg:hidden font-headline">BIMO</span>
          </Link>
          <nav className="flex flex-1 items-center space-x-6 text-sm">
            {navLinks.map((link) => (
              <Link
                key={link.href}
                href={link.href}
                className="font-bold text-primary-foreground/80 transition-colors hover:text-primary-foreground"
              >
                {link.label}
              </Link>
            ))}
          </nav>
          <CartButton />
        </div>

        <div className="flex flex-1 items-center justify-between space-x-2 md:hidden">
          <Link href="/" className="flex items-center space-x-2">
             <Star className="h-6 w-6" />
            <span className="font-bold font-headline">BIMO</span>
          </Link>
          <div className='flex items-center gap-2'>
            <CartButton />
            <Sheet>
              <SheetTrigger asChild>
                <Button variant="ghost" size="icon">
                  <Menu className="h-5 w-5" />
                  <span className="sr-only">Toggle Menu</span>
                </Button>
              </SheetTrigger>
              <SheetContent side="right" className="w-[300px] sm:w-[400px] p-0">
                <SheetHeader className="p-4 border-b">
                  <SheetTitle>Navigation Menu</SheetTitle>
                  <SheetDescription>
                    Explore Bright Ideas Multi Outlet (BIMO)
                  </SheetDescription>
                </SheetHeader>
                <nav className="flex flex-col space-y-4 mt-4 p-4">
                  {navLinks.map((link) => (
                    <Link
                      key={link.href}
                      href={link.href}
                      className="text-lg font-medium transition-colors hover:text-primary"
                    >
                      {link.label}
                    </Link>
                  ))}
                </nav>
              </SheetContent>
            </Sheet>
          </div>
        </div>
      </div>
    </header>
  );
}
