import Link from "next/link";

export function Footer() {
  return (
    <footer className="border-t py-6 md:py-8">
      <div className="container flex flex-col items-center justify-center gap-2 md:flex-row md:justify-between">
        <p className="text-center text-sm text-muted-foreground">
          &copy; {new Date().getFullYear()} Bright Ideas Multi Outlet (BIMO). All rights reserved.
        </p>
        <Link href="https://brightideasmultioutlet.com" target="_blank" rel="noopener noreferrer" className="text-sm text-muted-foreground hover:text-primary">
          brightideasmultioutlet.com
        </Link>
      </div>
    </footer>
  );
}
