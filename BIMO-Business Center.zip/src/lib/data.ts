import type { Outlet, Product, Service } from './types';
import { Bot, Code, Cpu, Database, Globe, Laptop, LucideIcon, Phone, Smartphone, ShoppingCart, Tablet, Tv, Wifi } from 'lucide-react';

// A helper type for icons.
type IconMap = {
    [key: string]: LucideIcon;
};

// It's a good practice to have a map for dynamic icons if needed, or just import them directly.
const languageIcons: IconMap = {
    python: Cpu,
    php: Code,
    java: Cpu,
    perl: Code,
    html: Code,
    css: Code,
    web: Globe,
    sql: Database,
    database: Database,
};


export const outlets: Outlet[] = [
  {
    slug: 'internet-cafe',
    name: 'Internet Cafe',
    description: 'Internet Cafe, Printing, Online Applications, Scholarships Applications, Jobs Applications, Consulting and Computer and Mobile Applications Development.',
    category: 'Services',
    icon: Wifi,
    address: '30 Circular Road, Freetown by Regent Road Junction',
    emails: ['bimointernetcafe@gmail.com', 'bimo.internet.cafe@brightideasmultioutlet.com'],
    phones: ['+23288677952', '+23279053433'],
    website: 'https://brightideasmultioutlet.com',
  },
  {
    slug: 'provision-shop',
    name: 'Provision Shop',
    description: 'Everyday essentials, snacks, and beverages.',
    category: 'Products',
    icon: ShoppingCart,
    address: 'Calaba Town Old Road Market by Central Mosque',
    emails: ['bimoprovisionshop@gmail.com'],
    phones: ['+23230080978', '+23288677952', '+23279053433'],
    website: 'https://brightideasmultioutlet.com',
  },
  {
    slug: 'electronics',
    name: 'Electronics',
    description: 'Latest gadgets, computers, and accessories.',
    category: 'Products',
    icon: Laptop,
    website: 'https://brightideasmultioutlet.com',
  },
  {
    slug: 'application-development',
    name: 'Application Development',
    description: 'Custom software, web, and mobile app solutions.',
    category: 'Services',
    icon: Code,
    emails: ['bimointernetcafe@gmail.com'],
    website: 'https://brightideasmultioutlet.com',
  },
];

export const products: Product[] = [
  // Internet Cafe
  { id: 'prod-001', name: '1 Hour Internet Access', description: 'Blazing fast fiber internet for one hour.', price: 15.00, isAvailable: true, outletSlug: 'internet-cafe' },
  { id: 'prod-002', name: 'PC Rental (Per Hour)', description: 'High-end PC for gaming or work.', price: 10.00, isAvailable: true, outletSlug: 'internet-cafe' },
  { id: 'prod-003', name: 'Colour Printing (per page)', description: 'High-quality color printing on A4 paper.', price: 5.00, isAvailable: true, outletSlug: 'internet-cafe' },
  { id: 'prod-011', name: 'Black and White Printing', description: 'Standard black and white printing per page.', price: 2.00, isAvailable: true, outletSlug: 'internet-cafe' },
  { id: 'prod-012', name: 'Photocopy Black and White', description: 'NLe 1 per page. For 50+ copies, price is NLe 0.50 per page.', price: 1.00, isAvailable: true, outletSlug: 'internet-cafe' },
  { id: 'prod-013', name: 'Laminating', description: 'Document laminating services.', price: 5.00, isAvailable: true, outletSlug: 'internet-cafe' },
  { id: 'prod-014', name: 'Brown Envelope', description: 'Standard size brown envelope for your documents.', price: 5.00, isAvailable: true, outletSlug: 'internet-cafe' },
  { id: 'prod-015', name: 'Online Application Assistance', description: 'Help with filling out and submitting online forms.', price: 100.00, isAvailable: true, outletSlug: 'internet-cafe' },
  { id: 'prod-016', name: 'Scholarship Application & Follow-up', description: 'Comprehensive help with scholarship applications and follow-up.', price: 500.00, isAvailable: true, outletSlug: 'internet-cafe' },
  { id: 'prod-017', name: 'Scanning', description: 'High-resolution document scanning.', price: 5.00, isAvailable: true, outletSlug: 'internet-cafe' },
  { id: 'prod-018', name: 'Dissertation Binding', description: 'Professional binding for your dissertation or thesis.', price: 20.00, isAvailable: true, outletSlug: 'internet-cafe' },
  { id: 'prod-019', name: 'Wooden Frame A4', description: 'High-quality wooden frame for A4 documents.', price: 250.00, isAvailable: true, outletSlug: 'internet-cafe' },
  { id: 'prod-020', name: 'A3 Frame', description: 'A sleek frame for your A3 posters and prints.', price: 300.00, isAvailable: true, outletSlug: 'internet-cafe' },
  { id: 'prod-021', name: 'A3+ Frame', description: 'A larger frame for your A3+ sized artwork.', price: 350.00, isAvailable: true, outletSlug: 'internet-cafe' },
  { id: 'prod-022', name: 'Canvas Printing', description: 'Print your photos or artwork on high-quality canvas.', price: 150.00, isAvailable: true, outletSlug: 'internet-cafe' },

  // Provision Shop
  { id: 'prod-004', name: 'Energy Drink (Can)', description: 'Chilled can of your favorite energy drink.', price: 12.00, isAvailable: true, outletSlug: 'provision-shop' },
  { id: 'prod-023', name: 'Energy Drink (Crate)', description: 'A full crate of your favorite energy drink.', price: 100.00, isAvailable: true, outletSlug: 'provision-shop' },
  { id: 'prod-024', name: 'Soft Drink', description: 'Fanta, Tippo, Apple Cedar and other assorted soft drinks.', price: 10.00, isAvailable: true, outletSlug: 'provision-shop' },
  { id: 'prod-005', name: 'Potato Chips', description: 'Large bag of classic salted potato chips.', price: 10.00, isAvailable: true, outletSlug: 'provision-shop' },
  { id: 'prod-006', name: 'Instant Noodles', description: 'Quick and easy meal for any time of day.', price: 13.00, isAvailable: true, outletSlug: 'provision-shop' },
  { id: 'prod-025', name: 'Rice (50kg Bag)', description: 'A large 50kg bag of high-quality rice.', price: 620.00, isAvailable: true, outletSlug: 'provision-shop' },
  { id: 'prod-026', name: 'Sugar (50kg Bag)', description: 'A large 50kg bag of granulated sugar.', price: 1000.00, isAvailable: true, outletSlug: 'provision-shop' },
  { id: 'prod-027', name: 'Rice (25kg Bag)', description: 'A 25kg bag of high-quality rice.', price: 340.00, isAvailable: true, outletSlug: 'provision-shop'},
  { id: 'prod-028', name: 'Rubber Drinks Crate', description: 'A crate of assorted rubber-bottled soft drinks.', price: 90.00, isAvailable: true, outletSlug: 'provision-shop'},
  { id: 'prod-029', name: 'Grafton/Bravery Water (Small)', description: 'A case of small bottled drinking water.', price: 40.00, isAvailable: true, outletSlug: 'provision-shop'},
  { id: 'prod-030', name: 'Grafton/Bravery Water (Big)', description: 'A case of large bottled drinking water.', price: 80.00, isAvailable: true, outletSlug: 'provision-shop'},
  { id: 'prod-031', name: 'Sachet Water', description: 'A bag of purified sachet drinking water.', price: 6.50, isAvailable: true, outletSlug: 'provision-shop'},


  // Electronics
  { id: 'prod-032', name: 'Dell Latitude Laptop (Core i5)', description: 'Reliable 14-inch business laptop with a Core i5 processor, 8GB RAM, and 256GB SSD.', price: 3500.00, isAvailable: true, outletSlug: 'electronics' },
  { id: 'prod-033', name: 'Lenovo IdeaPad Laptop (Core i3)', description: 'Versatile 15-inch laptop perfect for everyday use, with a Core i3 processor, 8GB RAM, and 512GB SSD.', price: 2500.00, isAvailable: true, outletSlug: 'electronics' },
  { id: 'prod-034', name: 'Dell OptiPlex Desktop (Core i5)', description: 'A powerful and compact desktop computer for your home or office, with a Core i5 CPU.', price: 1500.00, isAvailable: true, outletSlug: 'electronics' },
  { id: 'prod-035', name: 'USB Keyboard and Mouse Combo', description: 'A standard wired keyboard and optical mouse for reliable daily use.', price: 100.00, isAvailable: true, outletSlug: 'electronics' },
  { id: 'prod-036', name: 'Internal Hard Drive (1TB)', description: '1TB SATA internal hard drive to expand your computer\'s storage.', price: 850.00, isAvailable: true, outletSlug: 'electronics' },
  { id: 'prod-037', name: 'Portable Bluetooth Speaker', description: 'Compact and powerful wireless speaker for music on the go.', price: 500.00, isAvailable: true, outletSlug: 'electronics' },
  { id: 'prod-039', name: 'Computer Batteries', description: 'Replacement batteries for Dell and Lenovo laptops.', price: 850.00, isAvailable: true, outletSlug: 'electronics' },
];

export const services: Service[] = [
    {
        id: 'serv-002',
        name: 'Mobile App Development',
        description: 'Cross-platform mobile apps for iOS and Android that offer a seamless user experience.',
        icon: Smartphone,
        price: 2500
    },
    {
        id: 'serv-007',
        name: 'AI Powered Apps & Websites',
        description: 'We build scalable and robust web and mobile applications infused with the power of Artificial Intelligence.',
        icon: Code,
        price: 5000
    },
    {
        id: 'serv-008',
        name: 'AI Agents',
        description: 'Custom AI agents to automate tasks, improve customer service, and provide intelligent insights.',
        icon: Bot,
        price: 5000
    },
     {
        id: 'serv-014',
        name: 'Web Development & Design',
        description: 'Full-stack web development training, from front-end design to back-end logic.',
        icon: languageIcons.web,
        price: 5000
    },
    {
        id: 'serv-009',
        name: 'Python Tutorials',
        description: 'Learn the versatile Python language from scratch, from basic syntax to advanced topics.',
        icon: languageIcons.python,
        price: 500
    },
    {
        id: 'serv-010',
        name: 'PHP Tutorials',
        description: 'Master PHP for server-side web development and create dynamic websites.',
        icon: languageIcons.php,
        price: 500
    },
    {
        id: 'serv-011',
        name: 'Java Tutorials',
        description: 'Comprehensive tutorials on Java for building enterprise-level applications.',
        icon: languageIcons.java,
        price: 500
    },
    {
        id: 'serv-012',
        name: 'Perl Tutorials',
        description: 'Explore Perl for scripting, text manipulation, and system administration tasks.',
        icon: languageIcons.perl,
        price: 500
    },
    {
        id: 'serv-013',
        name: 'HTML & CSS Tutorials',
        description: 'The foundational building blocks of the web. Learn to structure and style web pages.',
        icon: languageIcons.html,
        price: 500
    },
    {
        id: 'serv-015',
        name: 'SQL & Database Tutorials',
        description: 'Learn to manage and query relational databases using SQL for powerful data insights.',
        icon: languageIcons.sql,
        price: 500
    },
];

export const getOutletBySlug = (slug: string) => outlets.find((o) => o.slug === slug);

export const getProductsByOutlet = (slug: string) => products.filter((p) => p.outletSlug === slug);

export const getServicesByOutlet = (slug: string) => {
    if (slug === 'application-development') {
        return services;
    }
    return [];
};
