import type { LucideIcon } from 'lucide-react';

export interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  isAvailable: boolean;
  outletSlug: string;
}

export interface Service {
  id: string;
  name:string;
  description: string;
  icon: LucideIcon;
  price: number;
}

export interface Outlet {
  slug: string;
  name: string;
  description: string;
  category: 'Products' | 'Services';
  icon: LucideIcon;
  address?: string;
  emails?: string[];
  phones?: string[];
  website?: string;
}

export interface OnlineService {
  id: string;
  name: string;
  description: string;
  url: string;
  icon: LucideIcon;
  category: string;
}

export type CartItem = (Product | Service) & {
    quantity: number;
    type: 'product' | 'service';
};
